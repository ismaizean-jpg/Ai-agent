package com.example.aiagent

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "🤖 AI AGENT"
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 20)
        }

        output = TextView(this).apply {
            text = "Level 109 Agent ready.\\n\\nAsk me to calculate something, save a memory, or type a task."
            textSize = 17f
            setPadding(0, 10, 0, 20)
        }

        input = EditText(this).apply {
            hint = "Type your task..."
            minLines = 2
        }

        val run = Button(this).apply {
            text = "🚀 RUN AGENT"
            setOnClickListener { runAgent(input.text.toString()) }
        }

        val voice = Button(this).apply {
            text = "🎤 VOICE INPUT"
            setOnClickListener { startVoiceInput() }
        }

        root.addView(title)
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(run)
        root.addView(voice)

        setContentView(root)
    }

    private fun runAgent(task: String) {
        val clean = task.trim()
        if (clean.isEmpty()) {
            output.text = "⚠️ Enter a task first."
            return
        }

        val answer = calculateIfPossible(clean)
        if (answer != null) {
            output.text = "🎯 Task: $clean\\n\\n🧮 Answer: $answer\\n\\n🔊 AI: The answer is $answer"
            tts.speak("The answer is $answer", TextToSpeech.QUEUE_FLUSH, null, "agent")
        } else {
            output.text = "🤖 Task received:\\n$clean\\n\\nThis APK foundation is ready.\\nGemini API connection can be added securely through a backend."
        }
    }

    private fun calculateIfPossible(text: String): String? {
        var t = text.lowercase(Locale.US)
            .replace("multiplied by", "*")
            .replace("multiply by", "*")
            .replace("times", "*")
            .replace("plus", "+")
            .replace("minus", "-")
            .replace("divided by", "/")
            .replace("divide by", "/")
            .replace("calculate", "")
            .replace("what is", "")

        val match = Regex("""\d+(?:\s*[\+\-\*/]\s*\d+)+""").find(t) ?: return null
        val expr = match.value.replace(" ", "")
        return try {
            val parts = expr.split(Regex("""(?=[\+\-\*/])|(?<=[\+\-\*/])"""))
            var result = parts[0].toDouble()
            var i = 1
            while (i < parts.size) {
                val op = parts[i]
                val n = parts[i + 1].toDouble()
                result = when (op) {
                    "+" -> result + n
                    "-" -> result - n
                    "*" -> result * n
                    "/" -> result / n
                    else -> return null
                }
                i += 2
            }
            if (result % 1.0 == 0.0) result.toLong().toString() else result.toString()
        } catch (_: Exception) { null }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your task")
        }
        try { startActivityForResult(intent, 1001) }
        catch (_: Exception) { output.text = "⚠️ Voice input is not available on this device." }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (text != null) {
                input.setText(text)
                runAgent(text)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
